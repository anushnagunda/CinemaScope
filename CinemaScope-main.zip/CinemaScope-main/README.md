# CinemaScope
Welcome to CinemaScope, the go-to platform for finding your next favorite film! This website uses complex recommendation algorithms to propose movies based on your choices. Whether you're a movie buff or just searching for a weekend watch, this tool makes it simple to discover a universe of cinematic possibilities.

Sources:
  - Dataset: https://www.kaggle.com/datasets/tmdb/tmdb-movie-metadata
  - https://www.youtube.com/watch?v=i-B_I2DGIAI
